create function spr_wiek() returns trigger
    language plpgsql
as
$$
BEGIN
 IF ((substring(NEW.pesel from 1 for 2) > '08') AND (substring(NEW.pesel from 1 for 2) < '21')) THEN
  RAISE EXCEPTION 'Wiek klienta: minumum 12 lat!';
 END IF;
 RETURN NEW;
END;
$$;

alter function spr_wiek() owner to u8grzesiak;

