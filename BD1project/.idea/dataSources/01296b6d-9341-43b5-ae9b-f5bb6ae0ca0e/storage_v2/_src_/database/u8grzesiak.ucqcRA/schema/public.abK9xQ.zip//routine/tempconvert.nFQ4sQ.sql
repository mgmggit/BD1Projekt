create function tempconvert(real)
    returns TABLE(c real, f real)
    language plpgsql
as
$$
BEGIN
FOR x IN 1 .. 100 BY 0.1 LOOP
INSERT INTO temp VALUES(x, $1*1,8+32);
END LOOP;
RETURN QUERY SELECT * FROM equation;
END;
$$;

alter function tempconvert(real) owner to u8grzesiak;

