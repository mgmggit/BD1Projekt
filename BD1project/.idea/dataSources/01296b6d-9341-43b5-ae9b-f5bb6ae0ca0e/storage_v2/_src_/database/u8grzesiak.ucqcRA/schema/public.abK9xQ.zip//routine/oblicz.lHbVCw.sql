create function oblicz(wypozyczenieid integer) returns real
    language plpgsql
as
$$
DECLARE
 result REAL;
BEGIN
 SELECT ((w.godzina_do - w.godzina_od)*c.cena_godzina) INTO result FROM wypozyczenia w
 JOIN egzemplarze e ON w.nr_rejestr = e.nr_rejestr
 JOIN hulajnogi h ON h.hulajnoga_id = e.hulajnoga_id
 JOIN cennik c ON c.klasa = h.klasa
 WHERE w.wypozyczenie_id = wypozyczenieID;
 RETURN result;
END;
$$;

alter function oblicz(integer) owner to u8grzesiak;

