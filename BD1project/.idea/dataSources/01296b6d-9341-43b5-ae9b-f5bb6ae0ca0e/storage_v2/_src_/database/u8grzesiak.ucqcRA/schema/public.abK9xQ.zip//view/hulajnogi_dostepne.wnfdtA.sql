create view hulajnogi_dostepne("Numer Rejestracyjny", "Klasa", "Rok nabycia") as
SELECT he.nr_rejestr AS "Numer Rejestracyjny",
       h.klasa       AS "Klasa",
       h.rok_nabycia AS "Rok nabycia"
FROM egzemplarze he,
     hulajnogi h
WHERE he.hulajnoga_id = h.hulajnoga_id
ORDER BY he.nr_rejestr;

alter table hulajnogi_dostepne
    owner to u8grzesiak;

