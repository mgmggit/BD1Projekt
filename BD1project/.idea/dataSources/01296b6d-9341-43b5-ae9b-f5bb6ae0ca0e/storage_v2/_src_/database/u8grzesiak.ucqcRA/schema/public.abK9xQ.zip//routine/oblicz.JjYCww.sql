create function oblicz() returns real
    language plpgsql
as
$$
DECLARE
 result REAL;
BEGIN
SELECT ((godzina_do.w - godzina_od.w)*cena_godzina.c) INTO result FROM
wypozyczenia w JOIN egzemplarze e ON w.nr_rejestr = e.nr_rejestr
JOIN hulajnogi h ON h.hulajnoga_id = e.hulajnoga_id
JOIN cennik c ON c.klasa = h.klasa;
RETURN result;
END;
$$;

alter function oblicz() owner to u8grzesiak;

