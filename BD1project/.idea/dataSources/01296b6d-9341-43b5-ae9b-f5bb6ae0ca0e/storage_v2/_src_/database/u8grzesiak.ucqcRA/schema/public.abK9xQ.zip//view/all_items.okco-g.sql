create view all_items(item_id, description, barcode_ean) as
SELECT i.item_id,
       i.description,
       b.barcode_ean
FROM item i,
     barcode b
WHERE i.item_id = b.item_id;

alter table all_items
    owner to u8grzesiak;

