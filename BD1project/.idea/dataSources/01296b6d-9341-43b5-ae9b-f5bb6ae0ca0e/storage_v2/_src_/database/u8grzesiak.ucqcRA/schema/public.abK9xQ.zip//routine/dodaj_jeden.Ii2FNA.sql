create function dodaj_jeden(integer) returns integer
    language plpgsql
as
$$
BEGIN
RETURN $1+1;
END;
$$;

alter function dodaj_jeden(integer) owner to u8grzesiak;

