create function lenvec(real, real) returns real
    language plpgsql
as
$$
DECLARE
x ALIAS FOR $1;
y ALIAS FOR $2;
BEGIN
RETURN sqrt(power(x, 2) + power(y, 2));
END;
$$;

alter function lenvec(real, real) owner to u8grzesiak;

