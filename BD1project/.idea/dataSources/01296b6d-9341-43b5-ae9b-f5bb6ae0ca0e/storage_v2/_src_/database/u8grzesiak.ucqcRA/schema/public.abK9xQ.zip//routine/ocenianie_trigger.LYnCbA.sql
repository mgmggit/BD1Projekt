create function ocenianie_trigger() returns trigger
    language plpgsql
as
$$
DECLARE 
studentID integer;
przedmiotID integer;
max_ocen integer;
num integer;
BEGIN
max_ocen := 3;
przedmiotID := NEW.przedmiot_id;
studentID := NEW.student_id;
SELECT count(*) INTO num FROM Ocena WHERE (studentID = student_id AND przedmiotID = przedmiot_id);
IF(num < 3) THEN
RAISE NOTICE 'Mozna dodac ocene:';
RETURN NEW;
ELSE 
RAISE NOTICE 'Nie mozna dodac wiecej niz 3 oceny!';
RETURN NULL;                                                   
END IF;                                                        
END;
$$;

alter function ocenianie_trigger() owner to u8grzesiak;

