create function ex01() returns text
    language plpgsql
as
$$
BEGIN
RETURN 'HELLO!';
END;
$$;

alter function ex01() owner to u8grzesiak;

