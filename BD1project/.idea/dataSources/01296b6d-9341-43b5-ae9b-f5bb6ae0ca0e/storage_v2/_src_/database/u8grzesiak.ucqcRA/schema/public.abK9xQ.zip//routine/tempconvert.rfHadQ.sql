create function tempconvert(i double precision)
    returns TABLE(c real, f real)
    language plpgsql
as
$$
BEGIN
FOR x IN 1 .. 100 BY $1 LOOP
INSERT INTO temp VALUES(x, x*1.8+32);
END LOOP;
RETURN QUERY SELECT * FROM temp;
END;
$$;

alter function tempconvert(double precision) owner to u8grzesiak;

