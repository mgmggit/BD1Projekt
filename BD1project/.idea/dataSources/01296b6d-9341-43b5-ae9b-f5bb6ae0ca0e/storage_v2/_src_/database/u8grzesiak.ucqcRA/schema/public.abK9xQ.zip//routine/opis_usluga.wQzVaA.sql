create function opis_usluga(n text) returns text
    language plpgsql
as
$$
DECLARE
 x RECORD;
BEGIN
 SELECT INTO x * FROM uslugi WHERE nazwa = n;
 RETURN x.opis;
END;
$$;

alter function opis_usluga(text) owner to u8grzesiak;

