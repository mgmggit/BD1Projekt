create view item_price(item_id, description, price) as
SELECT item.item_id,
       item.description,
       item.sell_price::double precision AS price
FROM item;

alter table item_price
    owner to u8grzesiak;

