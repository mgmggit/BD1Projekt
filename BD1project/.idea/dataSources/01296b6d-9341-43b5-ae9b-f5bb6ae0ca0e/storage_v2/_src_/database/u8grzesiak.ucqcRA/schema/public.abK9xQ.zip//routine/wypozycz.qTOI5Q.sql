create function wypozycz(k integer, nr_r character varying, g_od character varying, g_do character varying, nr_u integer) returns integer
    language plpgsql
as
$$
BEGIN
 INSERT INTO wypozyczenia(klient_id, nr_rejestr, godzina_od, godzina_do, usluga_nr) VALUES(k, nr_r, g_od, g_do, nr_u);
 RETURN 0;
END;
$$;

alter function wypozycz(integer, varchar, varchar, varchar, integer) owner to u8grzesiak;

