create function tempconvert()
    returns TABLE(x real, y real)
    language plpgsql
as
$$
BEGIN
FOR x IN 1 .. 1000 LOOP 
INSERT INTO temp VALUES (x/10, (x/10)*1.8+32);
END LOOP;
RETURN QUERY
SELECT * FROM temp;
END;
$$;

alter function tempconvert() owner to u8grzesiak;

