create function spr_rok() returns trigger
    language plpgsql
as
$$
BEGIN
 IF NEW.rok_nabycia < 2010 THEN
  RAISE EXCEPTION 'Tylko hulajnogi z rocznika 2010 lub nowsze!';
 END IF;
 RETURN NEW;
END;
$$;

alter function spr_rok() owner to u8grzesiak;

