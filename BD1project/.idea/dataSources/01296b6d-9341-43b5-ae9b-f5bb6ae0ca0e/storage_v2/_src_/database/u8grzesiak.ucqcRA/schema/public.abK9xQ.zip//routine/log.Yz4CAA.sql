create function log() returns trigger
    language plpgsql
as
$$
BEGIN
INSERT INTO log (table_name, operation) VALUES(TG_RELNAME, TG_OP);
RETURN NEW;
END;
$$;

alter function log() owner to u8grzesiak;

