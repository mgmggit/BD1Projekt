create function dodaj_klient(n text, i text, p character varying) returns integer
    language plpgsql
as
$$
BEGIN
 INSERT INTO klienci(nazwisko, imie, pesel) VALUES(n, i, p);
 RETURN 0;
END;
$$;

alter function dodaj_klient(text, text, varchar) owner to u8grzesiak;

