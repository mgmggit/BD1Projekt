create function opis_klient(nr integer) returns record
    language plpgsql
as
$$
DECLARE
 x RECORD;
BEGIN
 SELECT INTO x * FROM klienci AS k, telefony AS t
 WHERE k.klient_id = nr AND k.klient_id = t.klient_id;
 RETURN x;
END;
$$;

alter function opis_klient(integer) owner to u8grzesiak;

